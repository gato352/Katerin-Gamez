function showMessage() {
  const msg = document.getElementById('hiddenMessage');
  msg.classList.add('show');
  msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
