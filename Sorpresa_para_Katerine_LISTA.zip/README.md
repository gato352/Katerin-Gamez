# Sorpresa para Katerine ❤️

Página de cumpleaños creada para Katerine — 30 de septiembre de 2026.

## Publicación con GitHub Pages
1. Sube los archivos de esta carpeta a la raíz del repositorio.
2. En GitHub entra a **Settings → Pages**.
3. En **Build and deployment**, selecciona **Deploy from a branch**.
4. Branch: **main**.
5. Folder: **/(root)**.
6. Guarda y espera la publicación.

El archivo `index.html` debe quedar directamente en la raíz del repositorio.
